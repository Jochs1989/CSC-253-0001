﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TuitionLibrary;
using Xunit;

namespace TuitionLibraryTest
{
    public class TuitionTest
    {
        [Theory]
        [InlineData(0, 0, 50000)]
        [InlineData(1000, 10, 70000)]
        public void Add_IncreasebyIntrest(double x, double y, double expected)
        {
            // Arrange

            // Actual
            double actual = Tuition.RunTuitionCalculator(x,y);

            // Assert
            Assert.Equal(expected, actual);
        }
    }
}
