﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TuitionLibrary;

/*
* 11/17/2019
* CSC 253
* Jeffrey Ochs
* This program will tell a user the cost of tuition after 5 years AND TEST IT.
*/

namespace ConsoleUI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //boolean to allow the user to run or exit program
            bool exit = false;

            do
            {
                //user input to run or exit the program
                Console.WriteLine("Enter 1 To run program!");
                Console.WriteLine("Enter any other key to exit!\n");
                Console.Write("> ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Tuition.RunTuitionCalculator(0,0);
                }

                else
                {
                    exit = true;
                }

            } while (exit == false);

            

        }
    }
}
