﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionLibrary
{
    public class Tuition
    {
        public static double RunTuitionCalculator(double incTuition, double interest)
        {
            //variables initiated to zero for use in the loop
            double totalCost = 0;

            for (int count = 1; count <= 5; count++)
            {
                //calculations for tutition and a display of results for each year
                incTuition = incTuition + interest + 10000;
                interest = interest + (.02 * incTuition);
                totalCost = interest + incTuition;
                Console.WriteLine($"The cost of tution for year {count} is: {totalCost.ToString("C")}\n");
            }
            return totalCost;

        }
    }
}
