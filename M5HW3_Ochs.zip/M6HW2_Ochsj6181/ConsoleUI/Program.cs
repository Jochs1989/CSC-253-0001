﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRLibrary;

/**
* 05-30-2019
* CSC 153
* Jeffrey Ochs
* Created a class library and class to hold properties.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            Employee employee2 = new Employee("Mark Jones", 39119, "IT", "Programmer");
            Employee employee3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

            Console.WriteLine($"{employee1.Name}, {employee1.IdNumber}, {employee1.Department}, {employee1.Position}");
            Console.WriteLine($"{employee2.Name}, {employee2.IdNumber}, {employee2.Department}, {employee2.Position}");
            Console.WriteLine($"{employee3.Name}, {employee3.IdNumber}, {employee3.Department}, {employee3.Position}");
            Console.ReadLine();
        }
    }
}
