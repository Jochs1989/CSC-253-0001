﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HRLibrary;

namespace WindowsFormsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Employee employee1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            EmployeeName.Text = employee1.Name;
            EmployeeID.Text = employee1.IdNumber.ToString();
            EmployeeDepartment.Text = employee1.Department;
            EmployeePosition.Text = employee1.Position;
        }

        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Employee employee2 = new Employee("Mark Jones", 39119, "IT", "Programmer");
            EmployeeName.Text = employee2.Name;
            EmployeeID.Text = employee2.IdNumber.ToString();
            EmployeeDepartment.Text = employee2.Department;
            EmployeePosition.Text = employee2.Position;
        }

        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Employee employee3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
            EmployeeName.Text = employee3.Name;
            EmployeeID.Text = employee3.IdNumber.ToString();
            EmployeeDepartment.Text = employee3.Department;
            EmployeePosition.Text = employee3.Position;
        }
    }
}
