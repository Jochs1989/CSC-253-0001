﻿namespace WindowsFormsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmployeeName = new System.Windows.Forms.RichTextBox();
            this.Name = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.Label();
            this.Department = new System.Windows.Forms.Label();
            this.Position = new System.Windows.Forms.Label();
            this.EmployeeID = new System.Windows.Forms.RichTextBox();
            this.EmployeePosition = new System.Windows.Forms.RichTextBox();
            this.EmployeeDepartment = new System.Windows.Forms.RichTextBox();
            this.EmployeeBox = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.EmployeeBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // EmployeeName
            // 
            this.EmployeeName.Location = new System.Drawing.Point(100, 26);
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.Size = new System.Drawing.Size(165, 24);
            this.EmployeeName.TabIndex = 0;
            this.EmployeeName.Text = "";
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(6, 37);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(35, 13);
            this.Name.TabIndex = 1;
            this.Name.Text = "Name";
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Location = new System.Drawing.Point(6, 72);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(58, 13);
            this.ID.TabIndex = 2;
            this.ID.Text = "ID Number";
            // 
            // Department
            // 
            this.Department.AutoSize = true;
            this.Department.Location = new System.Drawing.Point(6, 107);
            this.Department.Name = "Department";
            this.Department.Size = new System.Drawing.Size(62, 13);
            this.Department.TabIndex = 3;
            this.Department.Text = "Department";
            // 
            // Position
            // 
            this.Position.AutoSize = true;
            this.Position.Location = new System.Drawing.Point(6, 143);
            this.Position.Name = "Position";
            this.Position.Size = new System.Drawing.Size(44, 13);
            this.Position.TabIndex = 4;
            this.Position.Text = "Position";
            // 
            // EmployeeID
            // 
            this.EmployeeID.Location = new System.Drawing.Point(100, 69);
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.Size = new System.Drawing.Size(165, 24);
            this.EmployeeID.TabIndex = 5;
            this.EmployeeID.Text = "";
            // 
            // EmployeePosition
            // 
            this.EmployeePosition.Location = new System.Drawing.Point(100, 143);
            this.EmployeePosition.Name = "EmployeePosition";
            this.EmployeePosition.Size = new System.Drawing.Size(165, 24);
            this.EmployeePosition.TabIndex = 6;
            this.EmployeePosition.Text = "";
            // 
            // EmployeeDepartment
            // 
            this.EmployeeDepartment.Location = new System.Drawing.Point(100, 104);
            this.EmployeeDepartment.Name = "EmployeeDepartment";
            this.EmployeeDepartment.Size = new System.Drawing.Size(165, 24);
            this.EmployeeDepartment.TabIndex = 7;
            this.EmployeeDepartment.Text = "";
            // 
            // EmployeeBox
            // 
            this.EmployeeBox.Controls.Add(this.Name);
            this.EmployeeBox.Controls.Add(this.EmployeePosition);
            this.EmployeeBox.Controls.Add(this.EmployeeDepartment);
            this.EmployeeBox.Controls.Add(this.ID);
            this.EmployeeBox.Controls.Add(this.Department);
            this.EmployeeBox.Controls.Add(this.EmployeeID);
            this.EmployeeBox.Controls.Add(this.Position);
            this.EmployeeBox.Controls.Add(this.EmployeeName);
            this.EmployeeBox.Location = new System.Drawing.Point(12, 12);
            this.EmployeeBox.Name = "EmployeeBox";
            this.EmployeeBox.Size = new System.Drawing.Size(309, 206);
            this.EmployeeBox.TabIndex = 8;
            this.EmployeeBox.TabStop = false;
            this.EmployeeBox.Text = "Employee";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(12, 224);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(55, 17);
            this.radioButton1.TabIndex = 9;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Susan";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(146, 224);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(49, 17);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Mark";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(280, 225);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(41, 17);
            this.radioButton3.TabIndex = 11;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Joy";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.RadioButton3_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 261);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.EmployeeBox);
            this.Text = "Form1";
            this.EmployeeBox.ResumeLayout(false);
            this.EmployeeBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox EmployeeName;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.Label Department;
        private System.Windows.Forms.Label Position;
        private System.Windows.Forms.RichTextBox EmployeeID;
        private System.Windows.Forms.RichTextBox EmployeePosition;
        private System.Windows.Forms.RichTextBox EmployeeDepartment;
        private System.Windows.Forms.GroupBox EmployeeBox;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
    }
}

