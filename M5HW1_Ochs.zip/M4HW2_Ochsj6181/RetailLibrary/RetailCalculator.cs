﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailLibrary
{
    public class RetailCalculator
    {


        //method for user to enter wholesale
        public static double GetWholesale()
        {
            bool exit = false;

            double wholesale;

            do
            {
                //asks user for wholesale
                Console.Write("Enter the Wholesale! > ");
                string input = Console.ReadLine();

                //validates users entry
                if (double.TryParse(input, out wholesale))
                {
                    if (input != "-1")
                    {
                        return wholesale;
                    }
                    else
                    {
                        exit = true;
                    }
                }
                else
                {
                    Console.WriteLine("Not a valid entry!");
                }

            } while (exit == false);

            return wholesale;
        }

        //method for user to enter markup percent
        public static double GetMarkup()
        {
            bool exit = false;

            double markup;

            do
            {
                //asks user for wholesale
                Console.Write("Enter the Markup! or -1 to exit > ");
                string input = Console.ReadLine();

                //validates users entry
                if (double.TryParse(input, out markup))
                {
                    if (input != "-1")
                    {
                        return markup;
                    }
                    else
                    {
                        exit = true;
                    }
                }
                else
                {
                    Console.WriteLine("Not a valid entry!");
                }
            } while (exit == false);

            return markup;
        }

        //method to calculate the retail price
        public static double CalulateRetail(double wholesale, double percent)
        {
            //variables for calculation
            double markup = wholesale * (percent / 100);
            double retailPrice = wholesale + markup;
            return retailPrice;
        }
    }
}
