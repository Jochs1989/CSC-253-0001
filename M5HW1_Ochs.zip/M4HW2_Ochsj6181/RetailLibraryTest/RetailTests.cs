﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLibrary;
using Xunit;

namespace HWLibrary.Tests
{
    public class RetailTests
    {
        [Fact]
        public void Retail_SimpleValueShouldCalculate()
        {
            // Arrange
            double expected = 11;

            // Act
            double actual = RetailCalculator.CalulateRetail(10, 10);
            // Assert
            Assert.Equal(expected, actual);
        }
    }
}
