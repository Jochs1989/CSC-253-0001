﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLibrary;

/*
* 11/17/2019
* CSC 253
* Jeffrey Ochs
* This program will allow the user to calculate AND TEST the retail price of a purchase.
*/

namespace ConsoleUI
{
    public class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                double retailPrice;

                retailPrice = RetailCalculator.CalulateRetail(RetailCalculator.GetWholesale(), RetailCalculator.GetMarkup());
                Console.WriteLine($"The retail price is {retailPrice.ToString("C")}.");
                Console.ReadLine();
                
            } while (exit == false);

        }
    }
}
